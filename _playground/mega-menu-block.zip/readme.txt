=== Mega Menu Block ===
Contributors:      ndiego
Tags:              block
Requires at least: 6.5
Tested up to:      6.5
Requires PHP:      7.0
Stable tag:        0.1.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Add mega menus to your website.

== Description ==

An exploratory mega menu block.

== Changelog ==

